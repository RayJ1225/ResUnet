import argparse
import os
from typing import Tuple

import numpy as np
import torch
from torch import optim

from core.res_unet_plus import ResUnetPlusPlus
from dataset.data_generator import create_dataloader
from utils.metrics import HybridLoss, rmse, peak_to_valley, zernike_mae


# 简单控制台日志，避免依赖 tensorboardX

def log_epoch(prefix: str, epoch: int, loss: float, img_loss: float, param_loss: float, metrics: dict) -> None:
    msg = [
        f"{prefix} epoch {epoch}",
        f"loss={loss:.4f}",
        f"img_loss={img_loss:.4f}",
        f"param_loss={param_loss:.4f}",
    ]
    for k, v in metrics.items():
        msg.append(f"{k}={v:.4f}")
    print(" | ".join(msg))


def train_one_epoch(
    model: ResUnetPlusPlus,
    loader: torch.utils.data.DataLoader,
    optimizer: optim.Optimizer,
    loss_fn: HybridLoss,
    device: torch.device,
) -> Tuple[float, float, float, dict]:
    model.train()
    total_loss = 0.0
    total_img = 0.0
    total_param = 0.0
    n = 0
    rmse_list, pv_list, mae_list = [], [], []

    for batch in loader:
        inputs = batch["input"].to(device)
        wavefront_gt = batch["wavefront"].to(device)
        coeffs_gt = batch["coeffs"].to(device)

        optimizer.zero_grad()
        outputs = model(inputs)
        loss, l_img, l_param = loss_fn(
            outputs["final"], wavefront_gt, outputs["coeffs"], coeffs_gt
        )
        loss.backward()
        optimizer.step()

        bsz = inputs.size(0)
        total_loss += loss.item() * bsz
        total_img += l_img.item() * bsz
        total_param += l_param.item() * bsz
        n += bsz

        rmse_list.append(rmse(outputs["final"].detach(), wavefront_gt))
        pv_list.append(peak_to_valley(outputs["final"].detach(), wavefront_gt))
        mae_list.append(zernike_mae(outputs["coeffs"].detach(), coeffs_gt))

    metrics = {
        "rmse": float(np.mean(rmse_list)),
        "pv": float(np.mean(pv_list)),
        "zernike_mae": float(np.mean(mae_list)),
    }
    return total_loss / n, total_img / n, total_param / n, metrics


def validate(
    model: ResUnetPlusPlus,
    loader: torch.utils.data.DataLoader,
    loss_fn: HybridLoss,
    device: torch.device,
) -> Tuple[float, float, float, dict]:
    model.eval()
    total_loss = 0.0
    total_img = 0.0
    total_param = 0.0
    n = 0
    rmse_list, pv_list, mae_list = [], [], []

    with torch.no_grad():
        for batch in loader:
            inputs = batch["input"].to(device)
            wavefront_gt = batch["wavefront"].to(device)
            coeffs_gt = batch["coeffs"].to(device)

            outputs = model(inputs)
            loss, l_img, l_param = loss_fn(
                outputs["final"], wavefront_gt, outputs["coeffs"], coeffs_gt
            )

            bsz = inputs.size(0)
            total_loss += loss.item() * bsz
            total_img += l_img.item() * bsz
            total_param += l_param.item() * bsz
            n += bsz

            rmse_list.append(rmse(outputs["final"], wavefront_gt))
            pv_list.append(peak_to_valley(outputs["final"], wavefront_gt))
            mae_list.append(zernike_mae(outputs["coeffs"], coeffs_gt))

    metrics = {
        "rmse": float(np.mean(rmse_list)),
        "pv": float(np.mean(pv_list)),
        "zernike_mae": float(np.mean(mae_list)),
    }
    return total_loss / n, total_img / n, total_param / n, metrics


def parse_args():
    parser = argparse.ArgumentParser(description="Wavefront reconstruction with ResUNet++ + Zernike prior")
    parser.add_argument("--data_root", type=str, required=True, help="数据根目录，需包含 train/valid 子目录，每个目录下为 .npz 样本")
    parser.add_argument("--zernike_basis", type=str, required=True, help="zernike_basis.npy 路径，形状 (N_terms, H, W)")
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--num_workers", type=int, default=4)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--alpha", type=float, default=1.0, help="图像域损失权重")
    parser.add_argument("--beta", type=float, default=10.0, help="系数域损失权重")
    parser.add_argument("--num_terms", type=int, default=15, help="Zernike 基函数项数，需与基底一致")
    parser.add_argument("--save_dir", type=str, default="checkpoints", help="模型保存目录")
    return parser.parse_args()


def main():
    args = parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    os.makedirs(args.save_dir, exist_ok=True)

    # 加载 Zernike 基底
    basis_np = np.load(args.zernike_basis)
    if basis_np.shape[0] != args.num_terms:
        raise ValueError(f"基底项数 {basis_np.shape[0]} 与 num_terms {args.num_terms} 不一致")
    basis = torch.from_numpy(basis_np)

    # 构建模型与优化器
    model = ResUnetPlusPlus(channel=2, basis=basis, num_zernike_terms=args.num_terms).to(device)
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    loss_fn = HybridLoss(alpha=args.alpha, beta=args.beta)

    # DataLoader
    train_loader, _ = create_dataloader(args.data_root, "train", args.batch_size, args.num_workers, shuffle=True)
    val_loader, _ = create_dataloader(args.data_root, "valid", args.batch_size, args.num_workers, shuffle=False)

    best_val = float("inf")
    for epoch in range(1, args.epochs + 1):
        train_loss, train_img, train_param, train_metrics = train_one_epoch(
            model, train_loader, optimizer, loss_fn, device
        )
        log_epoch("Train", epoch, train_loss, train_img, train_param, train_metrics)

        val_loss, val_img, val_param, val_metrics = validate(
            model, val_loader, loss_fn, device
        )
        log_epoch("Valid", epoch, val_loss, val_img, val_param, val_metrics)

        # 简单的最优保存策略
        if val_loss < best_val:
            best_val = val_loss
            save_path = os.path.join(args.save_dir, "wavefront_best.pt")
            torch.save({"model": model.state_dict(), "epoch": epoch, "val_loss": val_loss}, save_path)
            print(f"Saved best model to {save_path}")


if __name__ == "__main__":
    main()
