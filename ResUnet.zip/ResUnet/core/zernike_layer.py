import torch
import torch.nn as nn


class ZernikeReconstructionLayer(nn.Module):
    """可微的 Zernike 重建层（非训练参数）。

    输入：Zernike 系数 (B, N_terms)
    内部：使用预先计算好的 Zernike 基底矩阵 (N_terms, H, W)
    输出：粗略波前 (B, 1, H, W)
    """

    def __init__(self, basis: torch.Tensor) -> None:
        super().__init__()
        if basis.ndim != 3:
            raise ValueError("Zernike 基底应为 (N_terms, H, W)")
        # 将基底注册为 buffer，梯度不更新，但可随模型一起移动到GPU
        self.register_buffer("basis", basis.float())
        self.n_terms, self.height, self.width = basis.shape

    def forward(self, coeffs: torch.Tensor) -> torch.Tensor:
        if coeffs.ndim != 2:
            raise ValueError("coeffs 形状应为 (B, N_terms)")
        if coeffs.shape[1] != self.n_terms:
            raise ValueError(
                f"coeffs 维度 {coeffs.shape[1]} 与基底项数 {self.n_terms} 不一致"
            )
        # einsum 实现 sum_i c_i * Z_i，输出 (B, H, W)
        coarse = torch.einsum("bn,nhw->bhw", coeffs, self.basis)
        return coarse.unsqueeze(1)  # (B, 1, H, W)
