import torch
import torch.nn as nn

from core.modules import (
    ResidualConv,
    ASPP,
    AttentionBlock,
    Upsample_,
    Squeeze_Excite_Block,
)
from core.zernike_layer import ZernikeReconstructionLayer


class ResUnetPlusPlus(nn.Module):
    """用于稀疏子孔径波前重建的 ResUNet++。

    主要改动：
    - 输入通道变为 2（稀疏相位 + mask）。
    - Bottleneck 处增加全局均值池化 + MLP 预测 Zernike 系数。
    - 使用 ZernikeReconstructionLayer 生成粗略波前，再与解码器学习的残差相加。
    - 输出层激活改为线性（不做压缩），支持任意相位范围。
    """

    def __init__(
        self,
        channel: int,
        basis: torch.Tensor,
        num_zernike_terms: int,
        filters: list = None,
        mlp_hidden: int = 256,
    ):
        super().__init__()
        filters = filters or [32, 64, 128, 256, 512]

        # 编码端
        self.input_layer = nn.Sequential(
            nn.Conv2d(channel, filters[0], kernel_size=3, padding=1),
            nn.BatchNorm2d(filters[0]),
            nn.ReLU(),
            nn.Conv2d(filters[0], filters[0], kernel_size=3, padding=1),
        )
        self.input_skip = nn.Sequential(
            nn.Conv2d(channel, filters[0], kernel_size=3, padding=1)
        )

        self.squeeze_excite1 = Squeeze_Excite_Block(filters[0])
        self.residual_conv1 = ResidualConv(filters[0], filters[1], 2, 1)

        self.squeeze_excite2 = Squeeze_Excite_Block(filters[1])
        self.residual_conv2 = ResidualConv(filters[1], filters[2], 2, 1)

        self.squeeze_excite3 = Squeeze_Excite_Block(filters[2])
        self.residual_conv3 = ResidualConv(filters[2], filters[3], 2, 1)

        # Bottleneck: ASPP 捕获跨孔径长距离上下文
        self.aspp_bridge = ASPP(filters[3], filters[4])

        # 物理分支：预测 Zernike 系数
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.mlp = nn.Sequential(
            nn.Flatten(),
            nn.Linear(filters[4], mlp_hidden),
            nn.ReLU(inplace=True),
            nn.Linear(mlp_hidden, num_zernike_terms),
        )
        self.zernike_layer = ZernikeReconstructionLayer(basis)

        # 解码端：学习高频残差
        self.attn1 = AttentionBlock(filters[2], filters[4], filters[4])
        self.upsample1 = Upsample_(2)
        self.up_residual_conv1 = ResidualConv(filters[4] + filters[2], filters[3], 1, 1)

        self.attn2 = AttentionBlock(filters[1], filters[3], filters[3])
        self.upsample2 = Upsample_(2)
        self.up_residual_conv2 = ResidualConv(filters[3] + filters[1], filters[2], 1, 1)

        self.attn3 = AttentionBlock(filters[0], filters[2], filters[2])
        self.upsample3 = Upsample_(2)
        self.up_residual_conv3 = ResidualConv(filters[2] + filters[0], filters[1], 1, 1)

        self.aspp_out = ASPP(filters[1], filters[0])

        # 残差输出：线性卷积，不使用 Sigmoid
        self.residual_out = nn.Conv2d(filters[0], 1, kernel_size=1)

    def forward(self, x):
        # 编码
        x1 = self.input_layer(x) + self.input_skip(x)
        x2 = self.squeeze_excite1(x1)
        x2 = self.residual_conv1(x2)

        x3 = self.squeeze_excite2(x2)
        x3 = self.residual_conv2(x3)

        x4 = self.squeeze_excite3(x3)
        x4 = self.residual_conv3(x4)

        bottleneck = self.aspp_bridge(x4)

        # 物理分支：预测系数 + 生成粗波前
        coeffs = self.mlp(self.gap(bottleneck))  # (B, N_terms)
        coarse_wavefront = self.zernike_layer(coeffs)  # (B,1,H,W)

        # 解码：学习残差
        x6 = self.attn1(x3, bottleneck)
        x6 = self.upsample1(x6)
        x6 = torch.cat([x6, x3], dim=1)
        x6 = self.up_residual_conv1(x6)

        x7 = self.attn2(x2, x6)
        x7 = self.upsample2(x7)
        x7 = torch.cat([x7, x2], dim=1)
        x7 = self.up_residual_conv2(x7)

        x8 = self.attn3(x1, x7)
        x8 = self.upsample3(x8)
        x8 = torch.cat([x8, x1], dim=1)
        x8 = self.up_residual_conv3(x8)

        residual = self.aspp_out(x8)
        residual = self.residual_out(residual)

        # 最终输出：粗波前 + 残差
        final_wavefront = coarse_wavefront + residual

        return {
            "final": final_wavefront,
            "coarse": coarse_wavefront,
            "residual": residual,
            "coeffs": coeffs,
        }
