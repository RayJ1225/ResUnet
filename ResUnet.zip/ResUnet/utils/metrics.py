from torch import nn
import torch


class HybridLoss(nn.Module):
    """混合损失：图像域 MSE + 系数域 MSE。

    Loss_total = alpha * L_img + beta * L_param
    建议 beta 稍大（如 10.0），强化系数约束。
    """

    def __init__(self, alpha: float = 1.0, beta: float = 10.0):
        super().__init__()
        self.alpha = alpha
        self.beta = beta
        self.mse = nn.MSELoss()

    def forward(self, pred_wavefront, true_wavefront, pred_coeffs, true_coeffs):
        l_img = self.mse(pred_wavefront, true_wavefront)
        l_param = self.mse(pred_coeffs, true_coeffs)
        return self.alpha * l_img + self.beta * l_param, l_img, l_param


# https://github.com/pytorch/examples/blob/master/imagenet/main.py
class MetricTracker(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


# https://stackoverflow.com/questions/48260415/pytorch-how-to-compute-iou-jaccard-index-for-semantic-segmentation
def jaccard_index(input, target):

    intersection = (input * target).long().sum().data.cpu()[0]
    union = (
        input.long().sum().data.cpu()[0]
        + target.long().sum().data.cpu()[0]
        - intersection
    )

    if union == 0:
        return float("nan")
    else:
        return float(intersection) / float(max(union, 1))


# https://github.com/pytorch/pytorch/issues/1249
def dice_coeff(input, target):
    num_in_target = input.size(0)

    smooth = 1.0

    pred = input.view(num_in_target, -1)
    truth = target.view(num_in_target, -1)

    intersection = (pred * truth).sum(1)

    loss = (2.0 * intersection + smooth) / (pred.sum(1) + truth.sum(1) + smooth)

    return loss.mean().item()


def rmse(pred: torch.Tensor, target: torch.Tensor) -> float:
    """RMSE 指标，输出 float。"""

    return torch.sqrt(torch.mean((pred - target) ** 2)).item()


def peak_to_valley(pred: torch.Tensor, target: torch.Tensor) -> float:
    """PV 指标：预测与真值的差异峰-谷值。"""

    diff = (pred - target).flatten(start_dim=1)
    pv = diff.max(dim=1).values - diff.min(dim=1).values
    return pv.mean().item()


def zernike_mae(pred_coeffs: torch.Tensor, target_coeffs: torch.Tensor) -> float:
    """Zernike 系数平均绝对误差。"""

    return torch.mean(torch.abs(pred_coeffs - target_coeffs)).item()
