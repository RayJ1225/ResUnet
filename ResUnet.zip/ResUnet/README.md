# 项目说明（中文）

本项目基于 ResUNet++，加入 Zernike 物理先验与残差融合，用于从 7 个离散子孔径的稀疏波前数据重建全口径连续波前相位。

## 功能与特点
- 双通道输入：`channel0=稀疏相位`，`channel1=mask`，明确区分“无数据”与“零值”。
- 物理分支：在 bottleneck 预测 Zernike 系数，并通过可微 Zernike 层生成粗波前。
- 残差融合：解码器学习高频残差，最终输出 = 粗波前 + 残差；输出层为线性激活，支持任意相位范围。
- 混合损失：图像域 MSE + 系数域 MSE，可配置权重 `alpha/beta`。

## 目录结构
- `run.py`：波前重建训练脚本（新流程）。
- `preprocess.py`：旧分割任务的图像裁剪脚本（不适用于波前任务）。
- `train.py`：旧分割训练脚本（保留但与本任务无关）。
- `configs/default.yaml`：旧分割流程示例配置。
- `core/`
	- `res_unet_plus.py`：改造后的 ResUNet++，包含 Zernike 物理分支与残差融合。
	- `res_unet.py`、`unet.py`、`modules.py`：旧分割模型组件；`zernike_layer.py` 为可微 Zernike 层。
- `dataset/`
	- `data_generator.py`：波前任务的数据集与 DataLoader（.npz 双通道输入）。
	- `dataloader.py`：旧分割数据加载器（图像分割用）。
- `utils/`
	- `metrics.py`：混合损失、RMSE、PV、Zernike MAE 等指标。
	- `logger.py`、`augmentation.py`、`hparams.py`：旧分割工具。
- `tests/test_res_unet.py`：旧分割模型形状单测。

## 数据格式（波前任务）
每个样本一个 `.npz`，包含键：
- `input`：形状 `(H, W, 2)`，`[...,0]=稀疏相位`，`[...,1]=mask(0/1)`。
- `wavefront`：形状 `(H, W)`，全口径真值相位。
- `coeffs`：形状 `(N_terms,)`，对应 Zernike 系数。

目录约定：
- `data_root/train/*.npz`
- `data_root/valid/*.npz`

## Zernike 基底
- 需要预先生成 `zernike_basis.npy`，形状 `(N_terms, H, W)`，与数据分辨率、项数一致。
- 该基底在模型中注册为 buffer，不训练但可反向传播。

## 快速开始
1) 准备数据与基底：确保 `data_root/train|valid` 下有 `.npz`，并提供匹配的 `zernike_basis.npy`。
2) 训练命令示例：
```bash
python run.py \
	--data_root /path/to/data_root \
	--zernike_basis /path/to/zernike_basis.npy \
	--num_terms 15 \
	--epochs 50 \
	--batch_size 4 \
	--lr 1e-3 \
	--alpha 1.0 --beta 10.0
```
3) 设备：自动选择 CUDA，如需强制 CPU，可设置环境变量 `CUDA_VISIBLE_DEVICES=""` 或在代码中改为 `device = torch.device("cpu")`。
4) 模型保存：验证集最优权重保存在 `checkpoints/wavefront_best.pt`。

## 指标与损失
- 损失：`Loss_total = alpha * MSE_wavefront + beta * MSE_coeffs`。
- 指标：RMSE、Peak-to-Valley (PV)、Zernike 系数 MAE。

## 兼容性说明
- 旧的分割流程（`preprocess.py`/`train.py`/`dataloader.py`）仍在，但与本波前重建任务无直接关系。
- 若仅做波前重建，可忽略旧分割代码和配置。

## 项目目标：
项目名称：基于物理引导 ResUNet++ 的稀疏孔径波前重构
-1. 核心目标 (Core Objective)利用深度学习模型，从7个离散子孔径采样的稀疏波前数据中，利用 Zernike 多项式作为物理先验，反演并重构出高精度的全口径连续波前相位。
-2. 数据流与输入/输出规范 (Data Pipeline)
    2.1 输入数据设计 (Dual-Channel Input)为了解决稀疏孔径中“无数据区域”与“零相位值”混淆的问题，并保留子孔径的空间位置信息，采用双通道输入模式。数据格式：.npy (浮点型张量)，形状为 (Batch_Size, H, W, 2)。通道定义：Channel 0 (Phase)：稀疏相位图。7个子孔径区域保留真实相位值，其余缺失区域填充为 0。Channel 1 (Mask)：二值掩膜。7个子孔径区域标记为 1，缺失区域标记为 0。优势：明确告知网络哪些区域是可信测量值，哪些区域需要“脑补”。
    2.2 输出数据设计 (Dual Output)模型需要同时输出图像和物理参数，以实现物理约束。Output A (Wavefront)：重构后的全口径波前相位图 (Batch_Size, H, W, 1)。Output B (Coefficients)：对应的 Zernike 系数向量 (Batch_Size, N_terms)（如前15项或更多）。
    2.3 数据加载器改造废弃原项目的 cv2.imread（仅支持图像），重写 data_generator.py 以支持 .npy 格式读取。移除原有的数据增强（如旋转、翻转），因为波前像差具有特定的方向敏感性，随意的几何变换会破坏物理意义（除非同步变换 Zernike 系数）。
-3. 模型架构修改 (Architecture Modifications)
    3.1 骨干网络：ResUNet++ (保持优势)保留 ResNet Block（残差连接）以提取深层特征。保留 ASPP (空洞空间金字塔池化) 模块。这是处理稀疏孔径的关键，利用空洞卷积的大感受野跨越孔径间的空白区域，建立全局联系。保留 Attention Block，帮助网络聚焦于有数据的子孔径区域。
    3.2 物理引导分支 (Physics-Guided Branch)在编码器（Encoder）的最深层（Bottleneck）处引出一个新分支：结构：Global Average Pooling -> Dense Layers (全连接层) -> Linear Output。功能：直接从深层特征中回归预测 Zernike 系数。
    3.3 可微物理层 (Differentiable Zernike Layer)新增模块：编写一个自定义 Keras/TensorFlow 层。输入：预测出的 Zernike 系数。操作：加载预先计算好的 Zernike 基底矩阵 $Z_{basis}$，执行线性组合运算 $W_{coarse} = \sum C_i \cdot Z_i$。输出：由系数生成的“粗略”全口径波前（Coarse Wavefront）。特性：该层不可训练（冻结权重），但必须可导，以便梯度能反向传播回系数预测层。
    3.4 残差融合策略 (Residual Fusion)解码器 (Decoder)：原本的 U-Net 解码路径不再直接输出最终结果，而是负责学习高频残差 (Residual Map)（即 Zernike 拟合不出来的局部细节）。最终融合：Final Output = Zernike Coarse Wavefront + Residual Map。激活函数：输出层的激活函数必须从 Sigmoid 改为 Linear（线性），以支持任意范围的相位值。
-4. 训练策略与损失函数 (Training & Loss)
    4.1 混合损失函数 (Hybrid Loss)放弃原本的 Dice Loss（分割专用），改用回归损失。总 Loss 由两部分加权组成：图像域损失 ($L_{img}$)：最终输出波前与真值波前之间的 MSE (均方误差)。参数域损失 ($L_{param}$)：预测的 Zernike 系数与真值系数之间的 MSE。$$Loss_{total} = \alpha \cdot L_{img} + \beta \cdot L_{param}$$(建议 $\beta$ 设得较大，例如 10.0，因为系数数值通常很小)
    4.2 评价指标 (Metrics)RMSE (均方根误差)：光学领域最通用的评价标准。PV (Peak-to-Valley)：峰谷值误差。Zernike Error：前 N 项系数的平均绝对误差。
-5. 代码实现步骤清单 (Implementation Checklist)准备先验数据：生成 zernike_basis.npy (形状如 256x256x15)，作为物理层的固定的张量。数据预处理：将原始数据集转换为上述的双通道 .npy 格式，并划分 Train/Val/Test 集。重写 Generator：编写新的 WavefrontDataGen 类。构建物理层：实现 ZernikeReconstructionLayer 类。组装模型：修改 m_resunet.py，移除分类头，加入物理分支和残差融合。调整训练脚本：修改 run.py，配置新的 Loss 和 Optimizer。
-6. 预期效果通过这种**“双通道输入 + 物理先验嵌入”**的架构，模型应当能够：准确识别 7 个子孔径的位置（通过 Mask 通道）。利用 Zernike 分支保证重建出的波前在大范围缺失区域（孔径之间）保持平滑且符合光学物理规律（不会出现伪影）。利用 Residual 分支补充高阶像差细节，实现高精度的全口径重构。