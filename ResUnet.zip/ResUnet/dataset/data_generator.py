import glob
import os
from typing import Tuple, Optional

import numpy as np
import torch
from torch.utils.data import Dataset


class WavefrontDataset(Dataset):
    """双通道稀疏波前数据集。

    约定：每个样本使用一个 .npz 文件存储三个键：
    - input: 形状 (H, W, 2)，channel0=稀疏相位，channel1=mask。
    - wavefront: 形状 (H, W)，全口径真值相位。
    - coeffs: 形状 (N_terms,)，对应的 Zernike 系数真值。
    文件组织：root/train/*.npz 和 root/valid/*.npz，DataLoader 通过 glob 收集。
    如需自定义路径，可传入 file_list 覆盖。
    """

    def __init__(
        self,
        root_dir: str,
        split: str = "train",
        file_list: Optional[list] = None,
        dtype: torch.dtype = torch.float32,
    ) -> None:
        self.root_dir = root_dir
        self.split = split
        if file_list is None:
            pattern = os.path.join(root_dir, split, "*.npz")
            self.files = sorted(glob.glob(pattern))
        else:
            self.files = file_list
        if not self.files:
            raise RuntimeError(f"未找到数据文件: {root_dir}/{split}/*.npz")
        self.dtype = dtype

    def __len__(self) -> int:
        return len(self.files)

    def __getitem__(self, idx: int) -> dict:
        path = self.files[idx]
        data = np.load(path)
        input_arr = data["input"].astype(np.float32)  # (H, W, 2)
        wavefront = data["wavefront"].astype(np.float32)  # (H, W)
        coeffs = data["coeffs"].astype(np.float32)  # (N,)

        # 安全检查：掩膜应为0/1，稀疏区域应与掩膜一致
        # 这里不强制修改，只转换类型，便于调试时 assert。
        # 转为张量 (C, H, W)
        input_tensor = torch.from_numpy(input_arr).permute(2, 0, 1).to(self.dtype)
        wavefront_tensor = torch.from_numpy(wavefront).unsqueeze(0).to(self.dtype)
        coeffs_tensor = torch.from_numpy(coeffs).to(self.dtype)

        return {
            "input": input_tensor,
            "wavefront": wavefront_tensor,
            "coeffs": coeffs_tensor,
            "path": path,
        }


def create_dataloader(
    root_dir: str,
    split: str,
    batch_size: int,
    num_workers: int = 4,
    shuffle: bool = True,
) -> Tuple[torch.utils.data.DataLoader, WavefrontDataset]:
    """便捷函数：按 split 创建 DataLoader。"""

    dataset = WavefrontDataset(root_dir=root_dir, split=split)
    loader = torch.utils.data.DataLoader(
        dataset, batch_size=batch_size, shuffle=shuffle, num_workers=num_workers
    )
    return loader, dataset
